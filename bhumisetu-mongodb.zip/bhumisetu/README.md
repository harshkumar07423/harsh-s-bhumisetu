# 🌿 BhumiSetu — MongoDB Full-Stack Setup

Digital Land Records & Property Tax portal backed by **MongoDB + Express + Node.js**.

---

## 📁 Project Structure

```
bhumisetu/
├── server/
│   ├── server.js          ← Express REST API
│   ├── seed.js            ← Database seeder (run once)
│   └── models/
│       └── LandRecord.js  ← Mongoose schema
├── public/
│   ├── index.html         ← Frontend (served by Express)
│   ├── app.js             ← Frontend logic (fetch API calls)
│   └── style.css          ← Styles
├── .env                   ← MongoDB URI & port config
├── package.json
└── README.md
```

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start MongoDB
Make sure MongoDB is running locally:
```bash
mongod --dbpath /data/db
```
Or use **MongoDB Atlas** — update `MONGO_URI` in `.env`:
```
MONGO_URI=mongodb+srv://<user>:<password>@cluster0.xxxxx.mongodb.net/bhumisetu
```

### 3. Seed the Database
```bash
npm run seed
```
This inserts 5 sample land records into MongoDB.

### 4. Start the Server
```bash
npm start
# or for auto-reload during development:
npm run dev
```

### 5. Open the App
Visit: **http://localhost:3000**

---

## 🔌 REST API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/records` | List all land records |
| GET | `/api/records/search?q=KH-12/456` | Search by survey no. or tax ID |
| GET | `/api/records/:surveyNumber` | Get single record |
| POST | `/api/records` | Add new land record |
| PUT | `/api/records/:surveyNumber` | Update a record |
| GET | `/api/tax?id=PTX-1001&year=2025` | Calculate tax due |
| POST | `/api/tax/pay` | Process tax payment (updates MongoDB) |

---

## 🧪 Sample Survey Numbers
Try these in the app after seeding:
- `KH-12/456` (or Tax ID: `PTX-1001`)
- `SUR-987` (or Tax ID: `PTX-2102`)
- `PLOT/22A` (or Tax ID: `PTX-3345`)
- `KH-78/09` (or Tax ID: `PTX-4521`)
- `SUR-1122` (or Tax ID: `PTX-6789`)

---

## 📦 Dependencies
- **express** — HTTP server & routing
- **mongoose** — MongoDB ODM
- **cors** — Cross-origin requests
- **dotenv** — Environment config
- **nodemon** (dev) — Auto-restart on file change
